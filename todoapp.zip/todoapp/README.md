#TODO-APP REPO
Este é um repositorio com o aplicativo de exemplo para demonstrar como podemos 
fazer a implantanção de uma aplicação em um servidor web apache baseado no ubuntu
utilizando um aplicativo feito em PHP.


## pasta config
 arquivos de configuração
### install.sh
 script para instalação do aplicativo ( ainda em andamento)
### security
 versões diferentes do aplicativo com configurações mais seguras

#index.php
 aplicativo a ser implantado

